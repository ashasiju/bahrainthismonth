<!DOCTYPE html>

<html>

<head>

    <title>Bahrain This Month</title>

</head>

<body>

    <!--<h1>{{ $mailData['title'] }}</h1>-->

    <p><?php echo $mailData['body'];?></p>

   

    

</body>

</html>